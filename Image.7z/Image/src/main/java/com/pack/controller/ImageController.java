package com.pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.pack.dao.ImageDao;
import com.pack.dao.StudentDao;
import com.pack.model.Student;

@Controller
public class ImageController {

	@Autowired(required=true)
	@Qualifier(value="imageDao")
	ImageDao imageDao;
	
	@Autowired(required=true)
	@Qualifier(value="stuDao")
	private StudentDao stuDao;


	@RequestMapping(value = "/InsertImage", method = RequestMethod.POST)
	public ModelAndView save(@RequestParam(required=false,value="name") String name, @RequestParam(required=false,value="age") Integer age,
			@RequestParam(required=false,value="photo") MultipartFile photo) {

		try {
			imageDao.inserRecords(name, age, photo);
			List<Student> listStu = stuDao.stuList();
            ModelAndView model=new ModelAndView("index", "msg", "Records succesfully inserted into database.");
			model.addObject("listStu", listStu);
			return model;

		} catch (Exception e) {
			return new ModelAndView("index", "msg", "Error: " + e.getMessage());
		}
	}
}